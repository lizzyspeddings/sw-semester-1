import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.*;


public class ButtonPanel extends JPanel
{

	public ButtonPanel(final SpatialModel model)
	{
		super();
		
		// create buttons
		JButton reset = new JButton("Reset");
		JButton exit = new JButton("Exit");
		
		
		// add listeners
		reset.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					model.setNumberNodes(model.getInitialNumber());
					model.setThreshold(model.getInitialThreshold());
				}
			}

		);
		exit.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					System.exit(0);
				}
			}
		);
		
		// add to panel
		add(reset);
		add(exit);
		
	}
}