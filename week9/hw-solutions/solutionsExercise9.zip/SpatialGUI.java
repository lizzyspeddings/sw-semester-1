import javax.swing.JFrame;

public class SpatialGUI
{
	public static void main(String[] args)
	{
		SpatialNetwork net = new SpatialNetwork(100, 0.1);

		SpatialComponent comp = new SpatialComponent(net);
		
		JFrame frame = new JFrame("Spatial Network Viewer");
		frame.setSize(500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.add(comp);
		
		frame.setVisible(true);
	}
}