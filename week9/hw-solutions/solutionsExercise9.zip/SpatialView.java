import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.util.Observer;
import java.util.Observable;

public class SpatialView extends JPanel implements Observer
{
	private SpatialModel model;
	
	public SpatialView(SpatialModel model)
	{
		super();
		this.model = model;
	}
	
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D)g;
		
		int width = getWidth();
		int height = getHeight();
		
		g2.clearRect(0, 0, width, height);
		
		double dimension = Math.min(width, height);
		
		for(int i = 0; i < model.getNumberNodes(); i++)
		{
			// plot node i
			double x = model.getCoords(i).getX() * dimension;
			double y = model.getCoords(i).getY() * dimension;
			Spot p = new Spot(x, y, dimension/100.0);
			g2.fill(p);
			
			// now draw edges to other nodes
			for(int j = i+1; j < model.getNumberNodes(); j++)
			{
				if(model.connected(i, j))
				{
					double u = model.getCoords(j).getX() * dimension;
					double v = model.getCoords(j).getY() * dimension;

					Line2D.Double edge = new Line2D.Double(x, y, u, v);
					g2.draw(edge);
				}
			}
		}
	}
	
	public void update(Observable obs, Object obj)
	{
		repaint();
	}
	
}