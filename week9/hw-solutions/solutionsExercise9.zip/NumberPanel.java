import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JSlider;
import java.awt.BorderLayout;
import java.util.Observer;
import java.util.Observable;
import javax.swing.event.*;

public class NumberPanel extends JPanel implements Observer
{
	private JSlider slider;
	private SpatialModel model;
	
	public NumberPanel(final SpatialModel model, int min, int max, int value)
	{
		super();
		
		this.model = model;	
		
		//create slider & listener
		slider = new JSlider(min, max, value);
		slider.addChangeListener(new ChangeListener()
			{
				public void stateChanged(ChangeEvent e)
				{
					model.setNumberNodes(slider.getValue());
				}
			}
		);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.setLabelTable(slider.createStandardLabels((max-min)/10));
		slider.setMajorTickSpacing((max-min)/10);

				
		setLayout(new BorderLayout());
		add(new JLabel("Number of nodes"), BorderLayout.WEST);
		add(slider, BorderLayout.CENTER);
	}
	
	public void update(Observable obs, Object obj)
	{
		slider.setValue(model.getNumberNodes());
	}
}
		