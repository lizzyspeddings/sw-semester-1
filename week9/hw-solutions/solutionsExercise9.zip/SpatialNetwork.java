import java.awt.geom.Point2D;
import java.util.Random;
import java.util.ArrayList;

/**
A network of nodes distributed randomly in space and locally connected
*/
public class SpatialNetwork
{
	private ArrayList<Point2D.Double> node;
	private double threshold;
	
	/**
	Create spatial network in a 1x1 space
	@param numberNodes how many nodes
	@param threshold the threshold for connectivity
	*/
	public SpatialNetwork(int numberNodes, double threshold)
	{
		this.node = new ArrayList<Point2D.Double>();
		this.threshold = threshold;
		
		Random generator = new Random();
		
		for(int i = 0; i < numberNodes; i++)
		{
			// create random point
			node.add(new Point2D.Double(generator.nextDouble(), generator.nextDouble()));
		}
			
	}
	
	/**
	Get coordinates of a node
	@param index the index of the node
	@return co-ordinates of the node
	*/
	public Point2D.Double getCoords(int index)
	{
		return node.get(index);
	}
	
	/**
	Change number of nodes 
	@param numberNodes the new number of nodes
	*/
	public void setNumberNodes(int numberNodes)
	{
		int difference = numberNodes - getNumberNodes();
		if(difference > 0)
		{
			Random generator = new Random();

			for(int i = 0; i < difference; i++)
			{
				node.add(new Point2D.Double(generator.nextDouble(), generator.nextDouble()));
			}
		}
		else
		{
			for(int i = 0; i < -difference; i++)
			{
				node.remove(0);
			}
		}
	}

	
	/**
	Get number of nodes
	@return number of nodes
	*/
	public int getNumberNodes()
	{
		return node.size();
	}
	
	
	/**
	Change threshold of connectivity
	@param threshold the new threshold
	*/
	public void setThreshold(double threshold)
	{
		this.threshold = threshold;
	}
	
	
	/**
	Get the current threshold of connectivity
	@return the threshold
	*/
	public double getThreshold()
	{
		return threshold;
	}
	
	
	/**
	Test if two nodes are connected
	@param i index of the first node
	@param j index of the second node
	@return true if nodes are connected
	*/
	public boolean connected(int i, int j)
	{
		return node.get(i).distance(node.get(j)) <= threshold;
	}
	
}