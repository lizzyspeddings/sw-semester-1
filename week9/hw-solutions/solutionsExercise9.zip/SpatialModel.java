import java.util.Observable;
import java.awt.geom.Point2D;

/**
Model of spatial network
*/
public class SpatialModel extends Observable
{
	private SpatialNetwork network;
	private int initialNumber;
	private double initialThreshold;
	
	public SpatialModel(SpatialNetwork network)
	{
		this.network = network;
		this.initialNumber = network.getNumberNodes();
		this.initialThreshold = network.getThreshold();
	}
	
	/**
	Get coordinates of a node
	@param index the index of the node
	@return co-ordinates of the node
	*/
	
	public Point2D.Double getCoords(int index)
	{
		return network.getCoords(index);
	}
	
	
	/**
	Get initial number of nodes
	@return initial number of nodes
	*/
	public int getInitialNumber()
	{
		return initialNumber;
	}
	
	/**
	Get initial threshold
	@return initial threshold
	*/
	public double getInitialThreshold()
	{
		return initialThreshold;
	}
	
	
	/**
	Get number of nodes
	@return number of nodes
	*/
	public int getNumberNodes()
	{
		return network.getNumberNodes();
	}

	/**
	Change number of nodes and re-position them
	@param numberNodes the new number of nodes
	*/
	public void setNumberNodes(int numberNodes)
	{
		network.setNumberNodes(numberNodes);
		setChanged();
		notifyObservers();

	}

	
	/**
	Change threshold of connectivity
	@param threshold the new threshold
	*/
	public void setThreshold(double threshold)
	{
		network.setThreshold(threshold);
		setChanged();
		notifyObservers();
	}
	
	
	/**
	Get the current threshold of connectivity
	@return the threshold
	*/
	public double getThreshold()
	{
		return network.getThreshold();
	}
	
	
	/**
	Test if two nodes are connected
	@param i index of the first node
	@param j index of the second node
	@return true if nodes are connected
	*/
	public boolean connected(int i, int j)
	{
		return network.connected(i, j);
	}
	
}