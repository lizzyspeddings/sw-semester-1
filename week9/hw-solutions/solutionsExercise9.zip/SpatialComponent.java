import javax.swing.JPanel;
import java.awt.BorderLayout;

public class SpatialComponent extends JPanel
{
	public SpatialComponent(SpatialNetwork net)
	{
		// model
		SpatialModel model = new SpatialModel(net);
		
		// views
		SpatialView view = new SpatialView(model);
		
		model.addObserver(view);
		
		// controls & listeners
		ThresholdPanel threshold = new ThresholdPanel(model, 0, 100, (int)(net.getThreshold() * 100));
		NumberPanel number = new NumberPanel(model, 0, 200, net.getNumberNodes());
		ButtonPanel buttons = new ButtonPanel(model);
		
		model.addObserver(number);
		model.addObserver(threshold);
		
		// add views to panel
		setLayout(new BorderLayout());
		add(view, BorderLayout.CENTER);
		add(threshold, BorderLayout.SOUTH);
		add(number, BorderLayout.NORTH);
		add(new JPanel(), BorderLayout.WEST);
		add(buttons, BorderLayout.EAST);
	}
}
		

